﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Prog_Facturas.Migrations
{
    /// <inheritdoc />
    public partial class AddFactura : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DetallesProducto_Clientes_ClienteID",
                table: "DetallesProducto");

            migrationBuilder.RenameColumn(
                name: "ClienteID",
                table: "DetallesProducto",
                newName: "FacturaID");

            migrationBuilder.RenameIndex(
                name: "IX_DetallesProducto_ClienteID",
                table: "DetallesProducto",
                newName: "IX_DetallesProducto_FacturaID");

            migrationBuilder.CreateTable(
                name: "Facturas",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClienteID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Facturas", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Facturas_Clientes_ClienteID",
                        column: x => x.ClienteID,
                        principalTable: "Clientes",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Facturas_ClienteID",
                table: "Facturas",
                column: "ClienteID");

            migrationBuilder.AddForeignKey(
                name: "FK_DetallesProducto_Facturas_FacturaID",
                table: "DetallesProducto",
                column: "FacturaID",
                principalTable: "Facturas",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DetallesProducto_Facturas_FacturaID",
                table: "DetallesProducto");

            migrationBuilder.DropTable(
                name: "Facturas");

            migrationBuilder.RenameColumn(
                name: "FacturaID",
                table: "DetallesProducto",
                newName: "ClienteID");

            migrationBuilder.RenameIndex(
                name: "IX_DetallesProducto_FacturaID",
                table: "DetallesProducto",
                newName: "IX_DetallesProducto_ClienteID");

            migrationBuilder.AddForeignKey(
                name: "FK_DetallesProducto_Clientes_ClienteID",
                table: "DetallesProducto",
                column: "ClienteID",
                principalTable: "Clientes",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
