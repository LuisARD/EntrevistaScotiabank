﻿namespace Prog_Facturas.Models
{
    public class Cliente
    {
        public int ID { get; set; }
        public string Nombre { get; set; } = string.Empty;
    }
}
