﻿namespace Prog_Facturas.Models
{
    public class Factura
    {
        public int ID { get; set; }
        public int ClienteID { get; set; }
        public Cliente? Cliente { get; set; }
        public List<DetalleProducto> Detalles { get; set; } = new();
        public decimal Total => Detalles.Sum(d => d.Subtotal);
    }
}