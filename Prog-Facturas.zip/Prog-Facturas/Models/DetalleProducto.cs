﻿namespace Prog_Facturas.Models
{
    public class DetalleProducto
    {
        public int ID { get; set; }
        public int FacturaID { get; set; }
        public Factura? Factura { get; set; }
        public int ProductoID { get; set; }
        public Producto? Producto { get; set; }
        public int Cantidad { get; set; }
        public decimal Subtotal => (Producto?.Precio ?? 0) * Cantidad;
    }
}
