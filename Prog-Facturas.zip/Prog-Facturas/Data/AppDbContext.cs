﻿using Microsoft.EntityFrameworkCore;
using Prog_Facturas.Models;

namespace Prog_Facturas.Data
{
    public class AppDbContext : DbContext
    {
      public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
      {
      }

        public DbSet<Cliente> Clientes => Set<Cliente>();
        public DbSet<Producto> Productos => Set<Producto>();
        public DbSet<Factura> Facturas => Set<Factura>();
        public DbSet<DetalleProducto> DetallesProducto => Set<DetalleProducto>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Producto>()
                .Property(p => p.Precio)
                .HasPrecision(18, 2);

            modelBuilder.Entity<Cliente>().HasData(
                new Cliente { ID = 1, Nombre = "Juan Pérez" },
                new Cliente { ID = 2, Nombre = "María Gómez" },
                new Cliente { ID = 3, Nombre = "Carlos Rodríguez" }
            );

            modelBuilder.Entity<Producto>().HasData(
                new Producto { ID = 1, Nombre = "Laptop", Precio = 25000.00m },
                new Producto { ID = 2, Nombre = "Mouse", Precio = 500.00m },
                new Producto { ID = 3, Nombre = "Teclado", Precio = 1200.00m }
            );
        }
    }
}