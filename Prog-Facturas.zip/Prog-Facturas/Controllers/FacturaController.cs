﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Prog_Facturas.Models;
using Prog_Facturas.Services;

namespace Prog_Facturas.Controllers
{
    public class FacturaController : Controller
    {
        private readonly IFacturaService _facturaService;
        private readonly IClienteService _clienteService;
        private readonly IProductoService _productoService;

        public FacturaController(
            IFacturaService facturaService,
            IClienteService clienteService,
            IProductoService productoService)
        {
            _facturaService = facturaService;
            _clienteService = clienteService;
            _productoService = productoService;
        }
        public async Task<IActionResult> Index()
        {
            var facturas = await _facturaService.GetFacturasAsync();
            return View(facturas);
        }

        public async Task<IActionResult> Create()
        {
            await LoadSelectListsAsync();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            int clienteId,
            List<int> productoIds,
            List<int> cantidades)
        {
            if (clienteId <= 0)
            {
                ModelState.AddModelError("clienteId", "Debe seleccionar un cliente.");
            }

            if (productoIds.Count != cantidades.Count)
            {
                ModelState.AddModelError(string.Empty, "Los datos de los productos no son válidos.");
            }

            if (!ModelState.IsValid)
            {
                await LoadSelectListsAsync(clienteId);
                return View();
            }

            var factura = new Factura
            {
                ClienteID = clienteId
            };

            for (int i = 0; i < productoIds.Count; i++)
            {
                factura.Detalles.Add(new DetalleProducto
                {
                    ProductoID = productoIds[i],
                    Cantidad = cantidades[i]
                });
            }

            try
            {
                await _facturaService.CreateFacturaAsync(factura);

                foreach (var detalle in factura.Detalles)
                {
                    await _facturaService.AddDetalleAsync(detalle);
                }

                return RedirectToAction(nameof(Details), new { id = factura.ID });
            }
            catch (InvalidOperationException ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);

                await LoadSelectListsAsync(clienteId);
                return View();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            int id,
            [Bind("ID,ClienteID")] Factura factura)
        {
            if (id != factura.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var updated = await _facturaService
                        .UpdateFacturaAsync(id, factura);

                    if (!updated)
                    {
                        return NotFound();
                    }

                    return RedirectToAction(nameof(Index));
                }
                catch (InvalidOperationException ex)
                {
                    ModelState.AddModelError(string.Empty, ex.Message);
                }
            }

            await LoadSelectListsAsync(factura.ClienteID);
            return View(factura);
        }

        public async Task<IActionResult> Details(int id)
        {
            var factura = await _facturaService.GetFacturaByIdAsync(id);

            if (factura is null)
            {
                return NotFound();
            }

            return View(factura);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var factura = await _facturaService.GetFacturaByIdAsync(id);

            if (factura is null)
            {
                return NotFound();
            }

            return View(factura);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var deleted = await _facturaService.DeleteFacturaAsync(id);

            if (!deleted)
            {
                return NotFound();
            }

            return RedirectToAction(nameof(Index));
        }

        private async Task LoadSelectListsAsync(
            int? clienteId = null,
            int? productoId = null)
        {
            ViewBag.Clientes = new SelectList(
                await _clienteService.GetClientesAsync(),
                "ID",
                "Nombre",
                clienteId);

            ViewBag.Productos = new SelectList(
                await _productoService.GetProductosAsync(),
                "ID",
                "Nombre",
                productoId);
        }
    }
}