﻿using Prog_Facturas.Models;
namespace Prog_Facturas.Services
{
    public interface IClienteService
    {
        Task<IEnumerable<Cliente>> GetClientesAsync();
    }
}
