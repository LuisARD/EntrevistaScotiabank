﻿using Prog_Facturas.Models;

namespace Prog_Facturas.Services
{
    public interface IFacturaService
    {
        Task<IEnumerable<Factura>> GetFacturasAsync();
        Task<Factura?> GetFacturaByIdAsync(int id);
        Task CreateFacturaAsync(Factura factura);
        Task<bool> UpdateFacturaAsync(int id, Factura factura);
        Task<bool> DeleteFacturaAsync(int id);
        Task<bool> AddDetalleAsync(DetalleProducto detalle);
        Task<bool> RemoveDetalleAsync(int facturaId, int detalleId);
    }
}