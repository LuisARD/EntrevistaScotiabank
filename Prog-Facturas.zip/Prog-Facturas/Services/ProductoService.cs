﻿using Microsoft.EntityFrameworkCore;
using Prog_Facturas.Data;
using Prog_Facturas.Models;

namespace Prog_Facturas.Services
{
    public class ProductoService : IProductoService
    {
        private readonly AppDbContext _context;

        public ProductoService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Producto>> GetProductosAsync()
        {
            return await _context.Productos
                .AsNoTracking()
                .OrderBy(p => p.Nombre)
                .ToListAsync();
        }
    }
}