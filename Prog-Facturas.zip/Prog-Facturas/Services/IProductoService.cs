﻿using Prog_Facturas.Models;

namespace Prog_Facturas.Services
{
    public interface IProductoService
    {
        Task<IEnumerable<Producto>> GetProductosAsync();
    }
}