﻿using Microsoft.EntityFrameworkCore;
using Prog_Facturas.Data;
using Prog_Facturas.Models;

namespace Prog_Facturas.Services
{
    public class FacturaService : IFacturaService
    {
        private readonly AppDbContext _context;

        public FacturaService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Factura>> GetFacturasAsync()
        {
            return await QueryFacturas()
                .OrderBy(f => f.ID)
                .ToListAsync();
        }

        public async Task<Factura?> GetFacturaByIdAsync(int id)
        {
            return await QueryFacturas()
                .FirstOrDefaultAsync(f => f.ID == id);
        }

        public async Task CreateFacturaAsync(Factura factura)
        {
            await ValidateClienteAsync(factura.ClienteID);

            if (factura.Detalles is null || factura.Detalles.Count == 0)
            {
                throw new InvalidOperationException(
                    "La factura debe tener al menos un producto.");
            }

            var productoIds = factura.Detalles
                .Select(d => d.ProductoID)
                .ToList();

            if (productoIds.Count != productoIds.Distinct().Count())
            {
                throw new InvalidOperationException(
                    "No se puede agregar el mismo producto más de una vez.");
            }

            var productosExistentes = await _context.Productos
                .Where(p => productoIds.Contains(p.ID))
                .Select(p => p.ID)
                .ToListAsync();

            if (productosExistentes.Count != productoIds.Count)
            {
                throw new InvalidOperationException(
                    "Uno o más productos seleccionados no existen.");
            }

            if (factura.Detalles.Any(d => d.Cantidad <= 0))
            {
                throw new InvalidOperationException(
                    "La cantidad debe ser mayor que cero.");
            }

            _context.Facturas.Add(factura);

            await _context.SaveChangesAsync();
        }

        public async Task<bool> UpdateFacturaAsync(int id, Factura factura)
        {
            var existing = await _context.Facturas.FindAsync(id);
            if (existing is null)
            {
                return false;
            }

            await ValidateClienteAsync(factura.ClienteID);

            existing.ClienteID = factura.ClienteID;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteFacturaAsync(int id)
        {
            var existing = await _context.Facturas.FindAsync(id);
            if (existing is null)
            {
                return false;
            }

            _context.Facturas.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> AddDetalleAsync(DetalleProducto detalle)
        {
            if (!await _context.Facturas.AnyAsync(f => f.ID == detalle.FacturaID))
            {
                return false;
            }

            if (detalle.Cantidad <= 0)
            {
                throw new InvalidOperationException("La cantidad debe ser mayor que cero.");
            }

            if (!await _context.Productos.AnyAsync(p => p.ID == detalle.ProductoID))
            {
                throw new InvalidOperationException("El producto seleccionado no existe.");
            }

            var alreadyAdded = await _context.DetallesProducto
                .AnyAsync(d => d.FacturaID == detalle.FacturaID && d.ProductoID == detalle.ProductoID);
            if (alreadyAdded)
            {
                throw new InvalidOperationException("El producto ya está agregado a esta factura.");
            }

            _context.DetallesProducto.Add(detalle);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RemoveDetalleAsync(int facturaId, int detalleId)
        {
            var detalle = await _context.DetallesProducto
                .FirstOrDefaultAsync(d => d.ID == detalleId && d.FacturaID == facturaId);
            if (detalle is null)
            {
                return false;
            }

            _context.DetallesProducto.Remove(detalle);
            await _context.SaveChangesAsync();
            return true;
        }

        private IQueryable<Factura> QueryFacturas()
        {
            return _context.Facturas
                .AsNoTracking()
                .Include(f => f.Cliente)
                .Include(f => f.Detalles)
                    .ThenInclude(d => d.Producto);
        }

        private async Task ValidateClienteAsync(int clienteId)
        {
            if (!await _context.Clientes.AnyAsync(c => c.ID == clienteId))
            {
                throw new InvalidOperationException("El cliente seleccionado no existe.");
            }
        }
    }
}