﻿using Microsoft.EntityFrameworkCore;
using Prog_Facturas.Data;
using Prog_Facturas.Models;

namespace Prog_Facturas.Services
{
    public class ClienteService : IClienteService
    {
        private readonly AppDbContext _context;

        public ClienteService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Cliente>> GetClientesAsync()
        {
            return await _context.Clientes
                .AsNoTracking()
                .OrderBy(c => c.Nombre)
                .ToListAsync();
        }
    }
}